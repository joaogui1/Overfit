package com.example.projeto;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;

public class ChooseActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageButton start_button1;
    private ImageButton start_button2;
    private ImageButton start_button3;
    private ImageButton start_button4;
    private ImageButton backButton;

    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose);

        configureStartButtons();
        configureBackButton();
    }

    private void configureBackButton() {
        backButton = findViewById(R.id.closeButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ChooseActivity.this, MainActivity.class));
            }
        });
    }

    private void configureStartButtons() {
        start_button1 = findViewById(R.id.startButton1);
        start_button2 = findViewById(R.id.startButton2);
        start_button3 = findViewById(R.id.startButton3);
        start_button4 = findViewById(R.id.startButton4);

        start_button1.setOnClickListener(this);
        start_button2.setOnClickListener(this);
        start_button3.setOnClickListener(this);
        start_button4.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        startActivity(new Intent(ChooseActivity.this, SeeActivity.class));
    }
}