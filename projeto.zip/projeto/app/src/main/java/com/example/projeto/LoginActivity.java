package com.example.projeto;

import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.content.Context;

import android.content.SharedPreferences;

import android.widget.EditText;
import android.widget.Toast;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        String erro = "404";

        SharedPreferences userLoad = getSharedPreferences("user", Context.MODE_PRIVATE);

        if(!erro.equals(userLoad.getString("name", "404"))){
            Intent intent = new Intent( this , MainActivity.class);
            startActivity(intent);
        }

        final EditText name = findViewById(R.id.userName);
        final EditText age = findViewById(R.id.userAge);
        final EditText weight = findViewById(R.id.userWeight);
        final EditText height = findViewById(R.id.userHeight);
        //final Spinner goal = findViewById(R.id.selectIntensitySpinner);
        final Button confirm = findViewById(R.id.confirm);

        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int ageV;
                float weightV;
                float heightV;

                if (name.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(), "Nome Inválido", Toast.LENGTH_LONG).show();
                    return;
                }

                try{
                    ageV = Integer.parseInt(age.getText().toString());
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), "Idade Inválida", Toast.LENGTH_LONG).show();
                    return;
                }

                try{
                    weightV = Float.parseFloat(weight.getText().toString());
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), "Peso Inválido", Toast.LENGTH_LONG).show();
                    return;
                }

                try{
                    heightV = Float.parseFloat(height.getText().toString());
                }catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Altura Inválida", Toast.LENGTH_LONG).show();
                    return;
                }

                SharedPreferences.Editor user = getSharedPreferences("user", Context.MODE_PRIVATE).edit();
                user.putString("name", name.getText().toString());
                user.putInt("age", ageV);
                user.putFloat("weight", weightV);
                user.putFloat("height", heightV);
                //user.putString("goal", goal.getText().toString());
                user.putString("date", "2015-01-01");
                user.putInt("xp", 0);
                user.putInt("ex1", 0);
                user.putInt("ex2", 0);
                user.putInt("ex3", 0);
                user.putInt("ex4", 0);
                user.putInt("ex5", 0);
                user.putInt("ex6", 0);
                user.putInt("ex7", 0);
                user.putInt("ex8", 0);
                user.putInt("ex9", 0);
                user.putInt("ex10", 0);
                user.putInt("diasUsados", 1);
                user.apply();

                ArrumaData();

                Intent intent = new Intent( v.getContext() , MainActivity.class);
                startActivity(intent);

            }
        });
    }

    public void ArrumaData(){
        Calendar dataHoje = Calendar.getInstance();

        SharedPreferences userLoad = getSharedPreferences("user", Context.MODE_PRIVATE);

        int day = dataHoje.get(Calendar.DAY_OF_MONTH);
        int month = dataHoje.get(Calendar.MONTH);
        int year = dataHoje.get(Calendar.YEAR);
        String dateS = year + "-" + month + "-" + day;
        String dateS2 = userLoad.getString("date", "");

        Date date1 = null;
        Date date2 = null;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            date1 = sdf.parse(dateS);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        try {
            date2 = sdf.parse(dateS2);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        if (date1.compareTo(date2) > 0) {

            SharedPreferences.Editor user = getSharedPreferences("user", Context.MODE_PRIVATE).edit();
            for (int i = 0; i < date1.compareTo(date2); i ++){
                user.putInt("ex10", userLoad.getInt("ex9", -1));
                user.putInt("ex9", userLoad.getInt("ex8", -1));
                user.putInt("ex8", userLoad.getInt("ex7", -1));
                user.putInt("ex6", userLoad.getInt("ex5", -1));
                user.putInt("ex5", userLoad.getInt("ex4", -1));
                user.putInt("ex4", userLoad.getInt("ex3", -1));
                user.putInt("ex3", userLoad.getInt("ex2", -1));
                user.putInt("ex2", userLoad.getInt("ex1", -1));
                user.putInt("ex1", 0);
                user.apply();
            }

            user.putString("date", dateS);
            user.apply();

        } else if (date1.compareTo(date2) < 0){
            Toast.makeText(getApplicationContext(), "Erro na data.", Toast.LENGTH_LONG).show();
        }

    }
}