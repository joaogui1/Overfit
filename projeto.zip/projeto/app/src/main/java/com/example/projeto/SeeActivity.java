package com.example.projeto;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class SeeActivity extends AppCompatActivity {

    private ImageButton back_button;
    private ImageButton confirm_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_see);

        configureConfirmButton();
        configureBackButton();
    }

    private void configureBackButton() {
        back_button = findViewById(R.id.backButton);
        back_button.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                startActivity(new Intent(SeeActivity.this, MainActivity.class));
            }
        });
    }

    private void configureConfirmButton() {
        confirm_button = findViewById(R.id.backButton);
//        back_button.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//            }
//        })
    }
}
