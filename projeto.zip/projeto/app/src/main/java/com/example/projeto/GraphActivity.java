package com.example.projeto;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GridLabelRenderer;
import com.jjoe64.graphview.helper.StaticLabelsFormatter;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

public class GraphActivity extends AppCompatActivity {

    private ImageButton trainButton;
    private LineGraphSeries<DataPoint> series;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.graph);

        configureGraph();
        configureTrainButton();
    }

    public void configureTrainButton() {
        trainButton = findViewById(R.id.treinoButton);

        trainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(GraphActivity.this, MainActivity.class));
            }
        });
    }

    public void configureGraph() {
        GraphView graph = (GraphView) findViewById(R.id.graph);

        SharedPreferences userLoad = getSharedPreferences("user", Context.MODE_PRIVATE);

        series = new LineGraphSeries<DataPoint>(new DataPoint[] {
                new DataPoint(userLoad.getInt("diasUsados", - 1) -9, userLoad.getInt("ex10", -1)),
                new DataPoint(userLoad.getInt("diasUsados", - 1) -8, userLoad.getInt("ex9", -1)),
                new DataPoint(userLoad.getInt("diasUsados", - 1) -7, userLoad.getInt("ex8", -1)),
                new DataPoint(userLoad.getInt("diasUsados", - 1) -6, userLoad.getInt("ex7", -1)),
                new DataPoint(userLoad.getInt("diasUsados", - 1) -5, userLoad.getInt("ex6", -1)),
                new DataPoint(userLoad.getInt("diasUsados", - 1) -4, userLoad.getInt("ex5", -1)),
                new DataPoint(userLoad.getInt("diasUsados", - 1) -3, userLoad.getInt("ex4", -1)),
                new DataPoint(userLoad.getInt("diasUsados", - 1) -2, userLoad.getInt("ex3", -1)),
                new DataPoint(userLoad.getInt("diasUsados", - 1) -1, userLoad.getInt("ex2", -1)),
                new DataPoint(userLoad.getInt("diasUsados", - 1), userLoad.getInt("ex1", -1)),

        });

        graph.getGridLabelRenderer().setGridStyle(GridLabelRenderer.GridStyle.HORIZONTAL);

        if((userLoad.getInt("diasUsados", - 1) - 9) >= 1){
            graph.getViewport().setMinX(userLoad.getInt("diasUsados", - 1) - 9);
            graph.getViewport().setMaxX(userLoad.getInt("diasUsados", - 1));
        }
        else {
            graph.getViewport().setMinX(1);
            graph.getViewport().setMaxX(10);
        }

        graph.getViewport().setXAxisBoundsManual(true);
        graph.getGridLabelRenderer().setNumHorizontalLabels(10);


        series.setColor(Color.MAGENTA);
        series.setThickness(8);


        graph.addSeries(series);
    }
}
