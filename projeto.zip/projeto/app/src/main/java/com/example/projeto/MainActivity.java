package com.example.projeto;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity{

    private Button aerobico;
    private Button muscular;
    private ImageButton graphButton;
    private ImageButton backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrumaData();

        SharedPreferences.Editor user = getSharedPreferences("user", Context.MODE_PRIVATE).edit();
        SharedPreferences userLoad = getSharedPreferences("user", Context.MODE_PRIVATE);

        user.putInt("ex1", userLoad.getInt("ex1", -1)+10);

        configureStartButtons();
        configureGraphButton();
    }

    private void configureGraphButton() {
        graphButton = findViewById(R.id.graficoButton);

        graphButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, GraphActivity.class));
            }
        });
    }

    private void configureStartButtons() {
        aerobico = findViewById(R.id.aerobicoButton);
        muscular = findViewById(R.id.muscularButton);

        aerobico.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent( view.getContext() , ChooseActivity.class);
                intent.putExtra("idButton", "aerobic");
                startActivity(intent);
            }
        });


        muscular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent( view.getContext() , ChooseActivity.class);
                intent.putExtra("idButton", "weightlifting");
                startActivity(intent);
            }
        });
    }

    public void ArrumaData(){
        Calendar dataHoje = Calendar.getInstance();

        SharedPreferences userLoad = getSharedPreferences("user", Context.MODE_PRIVATE);

        int day = dataHoje.get(Calendar.DAY_OF_MONTH);
        int month = dataHoje.get(Calendar.MONTH);
        int year = dataHoje.get(Calendar.YEAR);
        String dateS = year + "-" + month + "-" + day;
        String dateS2 = userLoad.getString("date", "");

        Date date1 = null;
        Date date2 = null;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            date1 = sdf.parse(dateS);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        try {
            date2 = sdf.parse(dateS2);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        if (date1.compareTo(date2) > 0) {

            SharedPreferences.Editor user = getSharedPreferences("user", Context.MODE_PRIVATE).edit();
            for (int i = 0; i < date1.compareTo(date2); i ++){
                user.putInt("ex10", userLoad.getInt("ex9", -1));
                user.putInt("ex9", userLoad.getInt("ex8", -1));
                user.putInt("ex8", userLoad.getInt("ex7", -1));
                user.putInt("ex6", userLoad.getInt("ex5", -1));
                user.putInt("ex5", userLoad.getInt("ex4", -1));
                user.putInt("ex4", userLoad.getInt("ex3", -1));
                user.putInt("ex3", userLoad.getInt("ex2", -1));
                user.putInt("ex2", userLoad.getInt("ex1", -1));
                user.putInt("ex1", 0);
                user.putInt("diasUsados", userLoad.getInt("diasUsados", - 1) + 1);
                user.apply();
            }

            user.putString("date", dateS);
            user.apply();

        } else if (date1.compareTo(date2) < 0){
            Toast.makeText(getApplicationContext(), "Erro na data.", Toast.LENGTH_LONG).show();
        }

    }
}